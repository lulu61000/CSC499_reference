export var ErieSampleBaseUrl = 'audio_sample/';

export function setSampleBaseUrl(url) {
  ErieSampleBaseUrl = url;
}